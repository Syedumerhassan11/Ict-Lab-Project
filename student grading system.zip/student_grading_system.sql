
-- Create database
CREATE DATABASE IF NOT EXISTS StudentGradingSystem;
USE StudentGradingSystem;

-- Create 'students' table
CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    dob DATE,
    gender VARCHAR(10),
    contact_number VARCHAR(15),
    email VARCHAR(100),
    address VARCHAR(255),
    enrollment_date DATE,
    status VARCHAR(20)
);

-- Insert sample data into 'students'
INSERT INTO students (first_name, last_name, dob, gender, contact_number, email, address, enrollment_date, status)
VALUES
('John', 'Doe', '2005-05-14', 'Male', '123-456-7890', 'johndoe@example.com', '123 Main St', '2023-09-01', 'Active');


INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('2', 'Mike', 'Tyson', '2006-04-04', 'Male', '0321-989-0877', 'miketyson@gmail.com', 'London', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('3', 'Fatima', 'Parveen', '2006-04-05', 'Female', '0321-098-7565', 'fatimaparveen@gmail.com', 'Karachi', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('4', 'Alizeh', 'Raza', '2006-01-13', 'Female', '0321-988-4343', 'alizehraza@gmail.com', 'Karachi', '2023-09-02', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('5', 'Waqas', 'Khalil', '2005-09-09', 'Male', '0321-998-2022', 'waqaskhalil@gmail.com', 'Karachi', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('6', 'Boris', 'Johnson', '2006-07-06', 'Male', '0321-098-7676', 'borisjohnson@gmail.com', 'London', '2023-09-02', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('7', 'Mike', 'Donaldson', '2006-09-08', 'Male', '0321-444-5555', 'mikedonaldson@gmail.com', 'London', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('8', 'Smith', 'Krab', '2006-01-12', 'Male', '0321-980-4521', 'smithkrab@gmail.com', 'London', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('9', 'Ali', 'Shah', '2005-09-09', 'Male', '0321-777-2314', 'alishah@gmail.com', 'Karachi', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('10', 'Abbas', 'Afridi', '2005-11-11', 'Male', '0321098-4536', 'abbasafridi@gmail.com', 'Karachi', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('11', 'Abdul', 'Malik', '2006-12-12', 'Male', '0321-980-3456', 'abdulmalik@gmail.com', 'Karachi', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('12', 'Abida', 'Praveen', '2006-03-19', 'Female', '0321-143-2291', 'hsdkjb@gmail.com', 'Karachi', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('13', 'Rija', 'Shah', '2006-08-18', 'Female', '0321-789-4312', 'dfhdusfd@gmail.com', 'Karachi', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('14', 'Maham', 'mubeen', '2005-07-17', 'Female', '0321-999-4321', 'rijashahid@gmail.com', 'Karachi', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('15', 'Zainab', 'Lateef', '2006-09-18', 'Female', '0321-987-4354', 'mahammubeen@gmail.com', 'Karachi', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('16', 'Ubaidullah', 'Shah', '2006-09-21', 'Male', '0321-987-3214', 'ubaidullahshah@gmail.com', 'Karachi', '2023-09-02', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('17', 'Hamza', 'Rizvi', '2005-03-22', 'Male', '0321-456-9879', 'hamzarizvi@gmail.com', 'Karachi', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('18', 'Murtaza', 'Hasan', '2006-08-27', 'Male', '123-987-098', 'murtazahasan@gmail.com', 'Karachi', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('19', 'Nadir', 'Shah', '2006-04-28', 'Male', '231-0987-0563', 'nadirshah@gmail.com', 'Karachi', '2023-09-01', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('20', 'Asher', 'Adnan', '2005-01-21', 'Male', '456-121-4576', 'asheradnan@gmail.com', 'Karachi', '2023-09-02', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('21', 'Ali', 'Omer', '2004-09-12', 'Male', '098-765-4321', 'aliomer@gmail.com', 'Karachi', '2023-09-02', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('22', 'Usman', 'Shinwari', '2005-05-13', 'Male', '123-456-7890', 'usman@gmail.com', 'Karachi', '2023-09-02', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('23', 'Adeel', 'Abid', '2005-03-18', 'Male', '999-321-5467', 'adeelabid@gmail.com', 'Karachi', '2023-09-02', 'Active');
INSERT INTO `studentgradingsystem`.`students` (`student_id`, `first_name`, `last_name`, `dob`, `gender`, `contact_number`, `email`, `address`, `enrollment_date`, `status`) VALUES ('24', 'Jameel', 'Latif', '2006-12-20', 'Male', '111-111-3214', 'jameellatif@gmail.com', 'Karachi', '2023-09-02', 'Active');



-- Create 'teachers' table
CREATE TABLE teachers (
    teacher_id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    contact_number VARCHAR(15),
    department VARCHAR(50)
);

-- Insert sample data into 'teachers'
INSERT INTO teachers (first_name, last_name, email, contact_number, department)
VALUES
('Alice', 'Johnson', 'alicejohnson@gmail.com', '987-654-3210', 'Mathematics');
delete from teachers
where teacher_id=6;

-- Create 'subjects' table
CREATE TABLE subjects (
    subject_id INT AUTO_INCREMENT PRIMARY KEY,
    subject_name VARCHAR(100),
    teacher_id INT,
    semester VARCHAR(20),
    FOREIGN KEY (teacher_id) REFERENCES teachers(teacher_id)
);

-- Insert sample data into 'subjects'
INSERT INTO subjects (subject_name, teacher_id, semester)
VALUES
('Mathematics', 1, 'Fall 2024');

-- Create 'assignments' table
CREATE TABLE assignments (
    assignment_id INT AUTO_INCREMENT PRIMARY KEY,
    subject_id INT,
    assignment_name VARCHAR(100),
    assignment_type VARCHAR(50), -- e.g., Homework, Quiz, Exam
    weight DECIMAL(5,2), -- Percentage weight of the assignment
    due_date DATE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id)
);

-- Insert sample data into 'assignments'
INSERT INTO assignments (subject_id, assignment_name, assignment_type, weight, due_date)
VALUES
(1, 'Homework 1', 'Homework', 10.00, '2024-09-10'),
(1, 'Quiz 1', 'Quiz', 20.00, '2024-09-20'),
(1, 'Midterm Exam', 'Exam', 30.00, '2024-10-15'),
(1, 'Final Exam', 'Exam', 40.00, '2024-12-10');

-- Create 'grades' table
CREATE TABLE grades (
    grade_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    assignment_id INT,
    score DECIMAL(5,2), -- Score for the assignment
    max_score DECIMAL(5,2), -- Maximum possible score for the assignment
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (assignment_id) REFERENCES assignments(assignment_id)
);

-- Insert sample data into 'grades'
INSERT INTO grades (student_id, assignment_id, score, max_score)
VALUES
(1, 1, 9.00, 10.00),
(1, 2, 18.00, 20.00),
(1, 3, 25.00, 30.00),
(1, 4, 35.00, 40.00);

-- Create 'report_cards' table
CREATE TABLE report_cards (
    report_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    subject_id INT,
    semester VARCHAR(20),
    final_score DECIMAL(5,2), -- Final score for the subject
    grade VARCHAR(2), -- Letter grade (A, B, C, etc.)
    teacher_comments VARCHAR(255),
    date_generated DATE,
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id)
);

-- Insert sample data into 'report_cards'
INSERT INTO report_cards (student_id, subject_id, semester, final_score, grade, teacher_comments, date_generated)
VALUES
(1, 1, 'Fall 2024', 87.50, 'A', 'Excellent work and consistent performance.', '2024-12-20');
-- Query for finding out final score for each subject
SELECT
    student_id,
    SUM((score / max_score) * weight) AS final_score
FROM grades
JOIN assignments ON grades.assignment_id = assignments.assignment_id
WHERE student_id = 5 AND subject_id = 5;

